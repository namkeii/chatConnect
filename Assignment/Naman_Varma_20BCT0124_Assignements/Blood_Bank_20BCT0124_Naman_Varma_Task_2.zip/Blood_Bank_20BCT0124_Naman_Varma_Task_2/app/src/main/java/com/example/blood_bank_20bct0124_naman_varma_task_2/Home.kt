package com.example.blood_bank_20bct0124_naman_varma_task_2

import android.annotation.SuppressLint
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.painter.Painter
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class Home : ComponentActivity() {
    @SuppressLint("UnusedMaterialScaffoldPaddingParameter")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            Scaffold {
                LazyColumn(modifier = Modifier.fillMaxSize()) {
                    item {
                        ImageInstance(
                            painter = painterResource(id = R.drawable.news2),
                            contentDescription = "news1"
                        )
                        Text(
                            text = "Blood banks grapple with acute shortage",
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            textAlign = TextAlign.Center,
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp
                        )
                        Divider(color = Color.Black, thickness = 2.dp)
                    }
                    item {
                        ImageInstance(
                            painter = painterResource(id = R.drawable.news3),
                            contentDescription = "news"
                        )
                        Text(
                            text = "Mega blood donation camp at CKT College in Panvel to mark Savarkars birth anniversary on May 28",
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            textAlign = TextAlign.Center,
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp
                        )
                        Divider(color = Color.Black, thickness = 2.dp)
                    }
                    item {
                        ImageInstance(
                            painter = painterResource(id = R.drawable.news2),
                            contentDescription = "news"
                        )
                        Text(
                            text = "Crisis looms as city blood banks grapple with blood shortage",
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            textAlign = TextAlign.Center,
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp
                        )
                    }
                    item {
                        ImageInstance(
                            painter = painterResource(id = R.drawable.news3),
                            contentDescription = "news"
                        )
                        Text(
                            text = "Warning! Only 15 days of bloodstock in Pune's blood banks",
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            textAlign = TextAlign.Center,
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun ImageInstance(
    painter: Painter,
    contentDescription: String,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        elevation = 5.dp
    ) {
        Image(
            painter = painter,
            contentDescription = contentDescription,
            contentScale = ContentScale.FillWidth,
            modifier = Modifier.fillMaxWidth()
        )
    }
}

@Preview(showBackground = true)
@Composable
fun DefaultPreview2() {
    Home()
}
