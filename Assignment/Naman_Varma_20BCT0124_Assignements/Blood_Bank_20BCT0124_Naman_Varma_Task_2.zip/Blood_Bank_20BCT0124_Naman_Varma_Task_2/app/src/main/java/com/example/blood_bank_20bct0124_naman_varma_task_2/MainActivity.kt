package com.example.blood_bank_20bct0124_naman_varma_task_2
//20BCT0124 Name-"Naman Varma"

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.blood_bank_20bct0124_naman_varma_task_2.ui.theme.Blood_Bank_20BCT0124_Naman_Varma_Task_2Theme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            Blood_Bank_20BCT0124_Naman_Varma_Task_2Theme() {
                // A surface container using the 'background' color from the theme
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    RunInstagram()
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RunInstagram() {
    var userIdentifier by remember {
        mutableStateOf("")
    }
    var password by remember {
        mutableStateOf("")
    }

    Column(
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .fillMaxSize()
            .background(Color.LightGray)
    ) {
        //Language
        Text(
            text = "20BCT0124 Naman Varma",
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold,
            color = Color.Black
        )
        Spacer(modifier = Modifier.height(96.dp))

        // Logo (Stylish-Handwriting)
        Row {
            Image(
                painter = painterResource(id = R.drawable.blood),
                contentDescription = "Instagram",
                modifier = Modifier.width(250.dp)
            )
        }
        Spacer(modifier = Modifier.height(16.dp))

        //Username/Phone/Email
        Row {
            TextField(
                value = userIdentifier,
                onValueChange = { userIdentifier = it },
                colors = TextFieldDefaults.textFieldColors(containerColor = Color(0xfffbfafb)),
                placeholder = { Text("Mobile number or email address", color = Color.Gray) },
                modifier = Modifier
                    .width(320.dp)
                    .height(50.dp)
                    .border(1.dp, Color.LightGray)
            )
        }
        Spacer(modifier = Modifier.height(8.dp))

        // Password
        Row {
            TextField(
                value = password,
                onValueChange = { password = it },
                colors = TextFieldDefaults.textFieldColors(containerColor = Color(0xfffbfafb)),
                placeholder = { Text("Password", color = Color.Gray) },
                modifier = Modifier
                    .width(320.dp)
                    .height(50.dp)
                    .border(1.dp, Color.LightGray)
            )
        }
        Spacer(modifier = Modifier.height(16.dp))

        val mContext = LocalContext.current

        //Log in
        Button(
            onClick = {
                mContext.startActivity(Intent(mContext, Home::class.java))
            },
            colors = ButtonDefaults.buttonColors(Color.Red),
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier
                .padding(all = 5.dp)
                .width(320.dp)
        ) {
            Text(
                text = "Log In",
                fontWeight = FontWeight.Bold,
                fontSize = 20.sp,
                color = Color.White
            )
        }
        Spacer(modifier = Modifier.height(16.dp))

        //Divider
        Row {
            Divider(color = Color.LightGray, thickness = 1.dp, modifier = Modifier.width(185.dp))
            Text(
                text = "OR",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = Color.Gray
            )
            Divider(color = Color.LightGray, thickness = 1.dp, modifier = Modifier.width(200.dp))
        }
        Spacer(modifier = Modifier.height(16.dp))

        // Login with Facebook
        Row {

            Image(
                painter = painterResource(id = R.drawable.google),
                contentDescription = "facebook",
                modifier = Modifier.size(24.dp)
            )
            Text(
                text = " Log in with Google",
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp,
                color = Color.Red
            )
        }
        Spacer(modifier = Modifier.height(146.dp))

        //Sign-up Option
        Divider(color = Color.LightGray, thickness = 1.dp, modifier = Modifier.fillMaxWidth())
        Spacer(modifier = Modifier.height(16.dp))
        Row {
            Text(
                text = "Don't have an account? ",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = Color.Red
            )
            Text(
                text = "Sign up",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = Color.Red
            )
        }

    }
}